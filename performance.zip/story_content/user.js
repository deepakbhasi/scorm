function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6jU6bAfXmGF":
        Script1();
        break;
      case "6lMnmX0pHDm":
        Script2();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();
var currentDate = new Date();
var day = currentDate.getDate();
var month = currentDate.getMonth() + 1;
var year = currentDate.getFullYear();
var newDate = month + "/" + day + "/" +year;
//alert(newDate);
player.SetVar("sysDate", newDate);

var lmsAPI = parent;
var studName = lmsAPI.GetStudentName();
var array  = studName.split(',');
var newName = array[1] + '  ' + array[0];
player.SetVar("userName",newName);
}

function Script2()
{
  if (document.location.href.indexOf('html5') < 0) {
    GetPlayer().printSlide()
  } else {
    if(!window.hasPrintStyle){
      window.hasPrintStyle = true;
      var css = '@media print {body * {visibility: hidden; border: 1px hidden white;height: 80%;page-break-after: avoid;page-break-before: avoid;}#slidecontainer, #slidecontainer * {visibility: visible;}#slidecontainer {position: absolute;left: 0;top: 0;  }#slideframe {overflow: visible;}}',
      head = document.head || document.getElementsByTagName('head')[0],
      style = document.createElement('style');
      style.type = 'text/css';
      if (style.styleSheet){
        style.styleSheet.cssText = css;
      } else {
        style.appendChild(document.createTextNode(css));
      }
      head.appendChild(style);
    }
    var whereNow = $("#slidecontainer").offset(); 
    $("#slidecontainer").offset({top:0,left:0});
    window.print();
    $("#slidecontainer").offset(whereNow);
  }
}

